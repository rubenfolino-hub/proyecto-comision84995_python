
# Archivo: __init__.py

# Exponemos las clases principales del módulo 'cliente'
from .cliente import Cliente
from .cliente import ClienteVIP


